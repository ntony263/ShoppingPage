import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class HWDayOneThree {
  public static void main(String [] args){
    Scanner sc = new Scanner(System.in);
    int n = sc.nextInt();
    List<Integer> mList = new ArrayList<Integer>();
    if (n>=2 && n<=100){
      int input=0;
      int max=0;
      int min = 0;
      int maxLocation = -1;
      int minLocation = -1;
      for (int i=0;i<n;i++){
        input = sc.nextInt();
        if (input>=1 && input <=n){
          mList.add(input);
          if (i==0){
            max = input;
            min=input;
            maxLocation = minLocation = 0;
            
          }
          else {
            if (max<input){
              max = input;
              maxLocation = i;
            }
            
            if (min>input){
              min = input;
              minLocation = i;
            }
          }
        }
        else {
          break;
        }
      }
      if (mList.size()==n){
        int l =-1;
        int r = -1;
        int caseA = -1;
        int caseB = -1;
        if (minLocation > maxLocation){
          l = minLocation;
          r = maxLocation;
        }
        else {
          l = maxLocation;
          r = minLocation;
        }
        
        if (l!=0){
          
        }
      }
      System.out.println("Min="+min+" at " + minLocation + " Max=" + max+" at " + maxLocation);
    }
  }
}